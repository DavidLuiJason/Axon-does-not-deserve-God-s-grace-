# AXON OPEN ITEMS (everything not done; the owner's words recorded 2026-10-23; update with every merge)

Evidence labels: MEASURED, OWNER-REPORTED, DEVICE, NOT RUN, HYPOTHESIS. Nothing here is built unless it says so. Rule (roadmap section 1): nothing is added to a screen without a plan and a design check first.

## A. Look and feel (each needs a plan and a design check before any prompt)
- LIGHT AND DARK MODE (OWNER-REPORTED): the app has always been dark and the owner likes the design. Add a setting for light and dark (also "follow the phone"). The orange-red brand colour (logo and accents) stays the same; only text and background colours change.
- APP ICON (the picture under the app name on the phone's home screen; also called logo): NOT DESIGNED yet. Design it first, then build it.
- STATUS BAR (the top strip with time, notification icons, signal and battery): does not match the app's colour and theme. It must follow the page, like professional apps. In light mode it must follow the light page.
- INPUT HINT (the grey text in the empty message box): the owner liked a hint that changes, for example "/" for commands, but it must not change constantly: once per session or similar. Not decided.
- CHAT LIST (long-press on a chat): Rename, Delete, Export. No extra buttons.
- THE TOGGLE BUTTON above the message bar (the chat or web switch): its meaning depends on the page. Main chat: probably nothing (the owner already talks to AXON directly). AXON Web: dims the web page so the chat shows clearly; tapping again returns to scrolling. AXON App and other pages: to be decided page by page; some pages may share a meaning. A settings page lists each page and lets the owner choose what the button does there, from a list of possible actions.
- USER MANUAL in settings: what each button does and how AXON works.
- The owner asked that each part that should stay fixed on a screen really is fixed, and that every part is checked as "is it supposed to be this way?" (design check).

## B. Tools
- Image tools are incomplete (OWNER-REPORTED). The image view fix A09 (Image editor view) is with the owner for testing.
- Some tools are dimmed and lifeless (cannot be opened, no tool behind them). The dimmed entries are listed in `src/tools/toolCatalog.ts`; the list per tool group is NOT YET WRITTEN here.
- Most tools have not been tested on the phone, so it is not known whether they work (OWNER-REPORTED). Phone checks pending: A13 (Calculator keypad), A14 (Video Frames), A09 (image view).
- Video to Audio waits for the V1 probe and the native decision. Backup and Restore and Source hub S3 wait for the owner.

## C. Build and repository
- RED MARKS (OWNER-REPORTED, 2026-10-23): some red marks flash in the GitHub build. They have been there for a long time and the build still finishes (cloud build passed on the B03P merge). NOT shown to the Director yet; not known whether they are real errors. Action: the owner sends a screenshot or the log text; the Director classifies them. Not fixed now.
- The repository roadmap `docs/ROADMAP.md` was still v16.8 before this update; the root file `AXON_ROADMAP.md` is a stale v14.4 copy (already on `docs/CLEANUP_CANDIDATES.md` as stale).
- Measured state of the main chat screen: NOT RECORDED.

## D. Cleanup notes (stage Z; roadmap section 11)
- Cleanup is the LAST stage. Each item needs a reason and its proof; nothing is removed by name pattern.
- Example of why: `docs/prompts/` looks like clutter but holds live prompts (B03A's prompt lives there).
- The oldest roadmap v15.1 is already in `docs/archive/`; do not import it again, and do not read it unless a check names a section.
- Add every candidate to `docs/CLEANUP_CANDIDATES.md` (add only).

## E. Brain notes from the owner
- READING QUESTIONS (owner correction, 2026-10-23): for every message AXON silently asks ITSELF who it is for, what it is meant to do and what it refers to. These are internal checks in its own reading, NOT questions put to the user; it asks the user only when it cannot settle them itself (see `docs/BRAIN_PLAN.md`, addendum 2026-10-23).

## F. Added 2026-10-23 (night) from the owner's phone and cloud-build screenshots
**Red marks (MEASURED from the owner's screenshot of the cloud build, 2 errors, 4 warnings):**
- ERROR `tests/convertBlocks.test.ts` line 18: `notes.changes` possibly undefined. FIXED (fix pack TF6): `(notes.changes ?? [])`. Test runs, 1,101 assertions pass.
- ERROR `tests/batchPlan.test.ts` line 7: `message` does not exist on type `never` (the assert narrows the plan to success, so the failure branch has no type). FIXED (TF6): the failure branch reads the message through a cast. Test runs, 31 assertions plus 2,000 seeded operations pass.
- Both are slips inside TEST files, not app faults; the APK was still built because STRICT_CHECKS is false. After TF6 merges, check that the build shows 0 errors; then the owner may decide to turn the test gate on (open item "test gate").
- WARNING Node.js 20 deprecation (checkout@v4, setup-java@v4, setup-node@v4, upload-artifact@v4 are forced onto Node 24) and WARNING setup-java v4 should become v5: workflow file, changed BY HAND only (never in a zip); not urgent, no job yet.
- WARNING no AXON_DEBUG_KEYSTORE_B64 secret: each build gets a new random key, so the old app must be uninstalled first. Known; owner decides when to add the key.
- WARNING "Type check or tests failed. The APK is still built": the summary of the two errors above.

**Dimmed (unbuilt) tools, MEASURED in `src/tools/toolCatalog.ts`: 23 of 60 entries.** Media 10: Collage Maker, Picture to Table or Code (Image); Audio Converter, Text to Speech, Voice Library, Voice Cloner, Speech to Text (Audio); Video Converter, Video Maker, Video Downloader (Video). Files and Converters 2: PDF Tools, Document Converter. Text and Writing 2: Rephraser, Grammar Helper. Language 1: Translator. Web and Data 3: Content Extractor, Link Analyzer, Web Search. AXON Code 1: AXON Code. Finance 2: Currency Converter, Market Scope (owner builds Market Scope in another account). Device and System 2: AI Assistant, Backup and Restore. Note: the Video Downloader and the Voice tools are LEFT OUT by earlier owner decisions; the owner may reopen any of them.

**QR Code Maker choice row (A15, prompt written, HELD until the repository is merged and green):** the five choices (Text, Link, Wi-Fi, Phone, Email) wrap and shift because the selected button is bolder and wider. Fix: equal-width, one line, same weight, no jump. Nothing added to the screen.

**QR SCANNER (PLAN FIRST, no prompt yet; owner idea 2026-10-23):** same screen as the QR Code Maker, a quiet two-way choice at the top, "Make" and "Scan", in the existing look (no new colours, no boxed cards). Scan: "Scan with camera" and "Choose a picture". Result shown as text with Copy; a link is only opened when the owner taps it; Wi-Fi codes show the name and security, never the password in bold. Needs, in order: (1) a measurement on the owner's phone: does the app's web view offer camera access and the browser's built-in barcode detector, or is a decoder library needed (size and licence checked first); (2) the Android camera permission, a native step by the Director; (3) a pure decoder engine and tests by ChatGPT (reads pixels, returns text and a clear failure); (4) the screen by AI Studio. Honest limit: unmeasured; labelled HYPOTHESIS until step 1.

**STATUS BAR (owner, again):** the top strip (time, notifications, alarm, network, battery) has its own colour and does not match the page. This is NATIVE Android styling (theme and status-bar settings in the Android overlay), not an AI Studio screen job; plan it together with light and dark mode (section A) so that it follows the page colour in both.

**TOOLS THAT DESCRIBE THEMSELVES (owner, 2026-10-23: room to add more tools later):** every tool, now and in future, carries a short description of what it does, needs and returns, declared once in the registry (FL10). From that one place AXON (a) answers "what can you do", (b) builds the user manual in settings, and (c) shows the tool in the menu. Adding a tool then means adding its registry entry; nothing else is edited by hand. Check at the next brain job (B04) that the registry has the fields the manual needs; add only what is missing. A test keeps menu, registry and manual in step.

**AXON CODE AND HEAVY PYTHON (owner question; ideas, NOT a promise; for AC2 to AC4):** see the Director's reply of 2026-10-23: honest limits and a design of (a) streaming and chunked helpers, (b) storage-backed containers, (c) checkpoint and resume, (d) measured memory caps per phone tier. To be written as `docs/AXON_CODE_PLAN.md` addendum when AC2 starts, after measurement on the owner's phone.

**Owner is testing the other tools** and will report problems; each report becomes a line here before any fix prompt (no piling).

**CHECKED IMPORT INTO MY DICTIONARY (owner idea, 2026-10-23):** the owner imports a list of ANY size (1,000 was only an example) as txt, md, zip or pasted text. Steps: (1) the Director writes a CHECKING PROMPT for an outside AI tool (Claude, ChatGPT or Grok) that returns each entry marked right, wrong or unsure with a reason; (2) the owner imports only what passed; (3) every entry keeps source, date and checker; (4) the brain reads these entries as a second knowledge source and as the standby dictionary, never over the core dictionary. The engine (C18) already stages an import and adds nothing until the owner says yes; what is missing is the checking prompt and the "checked by" field. Plan before any screen change.
**ACCENTS AND SPEECH (owner has an accent):** the phone's recogniser writes the words; AXON cannot change how it listens. What AXON can do: a personal "heard as" list (what the recogniser wrote, what was meant), learned from the owner's own corrections and kept in My Dictionary, applied before the brain reads the message. A real accent model is NOT promised (HYPOTHESIS; needs measurement on the owner's voice).

**MY DICTIONARY WITHOUT A CAP, SHOWN IN THE DICTIONARY (owner, 2026-10-23; PLAN FIRST):** (1) MEASURED today: `USER_DICT_LIMITS` allow 20,000 entries and 3 MB in one browser store, and an import file may be 5 MB or 20,000 rows. That is a cap, against the owner's wish. A storage job (C25, engine only) moves the entries to chunked storage on the phone (many small blocks, saved and read exactly, with the same undo and export), so size is limited only by free space; the weak-phone limit on how much is loaded at once stays. (2) MEASURED: `src/components/DictionaryScreen.tsx` does not read My Dictionary at all, so words added there never appear in the Dictionary search. Wanted: a Dictionary search also returns My Dictionary entries, each with a small My Dictionary icon (or dot); tapping it shows a short note: "Added from My Dictionary, not from AXON's original." No new box, no new colours; the icon only. Needs a design check, then an AI Studio job (A19) after C25. (3) The brain already reads My Dictionary as a source (BRAIN_PLAN).

## G. Added 2026-10-24 (B03A)
- Owner: confirm or strike the 9 conversation words (src/brain/knowledge/conversationWords.ts; all 'proposed').
- B03A known limits (docs/reports/B03A_REPORT.md): a statement that starts with a noun-verb word and has no auxiliary ("light travels fast") reads as a command; one bare noun-verb word ("stop") is not guessed; "I thank you" is unknown because the dictionary phrase "thank you" swallows the verb; typos are not repaired. Each belongs to a later brain job, not to a patch.
- Red mark tests/qrDecode.test.ts line 30: FIXED in the B03A package.
- Sandbox note: tests that need the jszip package (capabilityTruth, engineTruth, userDictionaryImport, zipTool) could not run in the Director sandbox; they run in the cloud build.

## H. Owner's message of 2026-10-25 (recorded by the Director; the owner decides what is built, in what order)
Labels: OWNER-REPORTED unless MEASURED.
1. **DESIGN MATCH (law, roadmap 1):** everything added must match the current design. The owner will not repeat it.
2. **NO MAXIMUM-CHARACTER LIMITS.** Keep live counts ("9,705 characters"), remove "of N" and the caps. MEASURED 2026-10-25 in `src/components/toolScreens`: TextCleanerScreen (maxLength and an "exceeds maximum limit" message), SortLinesScreen (same, plus a line limit), CaseConverterScreen (same), CodeFormatterScreen (maxLength = maxBytes), QrMakerScreen (maxLength = maxInputBytes), JsonViewerScreen (512 KB file limit), MyDictionaryScreen (maxLength on word, meaning, example: owner to say whether these stay). Not character limits, ask the owner: Tally Counter keeps 100 undo steps and safe integers. Engines carry the same limits in their `*_LIMITS` constants; engine and screen change together. The removal needs a plan (what happens with a 50 MB paste on the weakest phone: process in pieces, warn, never refuse silently).
3. **WORK SURVIVES CLOSING THE APP; every input page gets a Clear or Remove control** (uploaded file or pasted text can currently not be removed on some pages). Same design as the rest.
4. **MICROPHONE ON EVERY NOTE FIELD** (same button as the main chat).
5. **Password Generator:** history of generated passwords; Save asks for an optional note (note has the microphone).
6. **Each tool gets a how-to page** (what it does, how to use it) when the action manual is added. The owner withdrew the "scroll between tool pages" idea.
7. **Device Profile is incomplete:** show FREE memory and FREE storage now (not only 4 GB total), refresh by itself (keep the Refresh button), and later a PREFLIGHT: before heavy work AXON estimates the space and memory the job needs and warns before starting. Needs a measured source for free memory and storage on Android (HYPOTHESIS: the web layer cannot read free RAM; may need the native bridge).
8. **Text Cleaner is too thin and provisional.** Wanted: knows code or other material that must not be touched; fixes capitals, commas, full stops and question marks by reading the sentence; fixes spelling slips using the dictionary but treats unknown words (names, EFCC) as possibly right; optional internet or outside-AI check behind a toggle. This is the Writer plus the brain's reading: plan it after B03B2/B03B3 (Think-Through first).
9. **Pattern Tester does not count repeated patterns or find patterns** (owner could not see what it does). Re-examine against its purpose (Think-Through).
10. **Summarizer does not work properly** (the owner accepts this as expected: it has no understanding). Rebuild on the brain's reading (S2). Do not use it on prompts.
11. **Image editor is far from InShot** (hundreds of filters, etc.). The owner's aim: every common thing the high-end photo, video and audio editors do, better than InShot because AXON has AI. This conflicts with the 2026-10-20 LEFT OUT list for video and audio editors. NEEDS an owner decision: a rival table (what InShot does, what AXON does, the gap) and a plan before any more editor work.
12. **Background Proof** (`src/components/BackgroundProofScreen.tsx`, `src/background/`): the owner feels something is wrong but cannot say what. Director to audit it (read the screen and engine, say plainly what it proves and what it does not).
13. **JSON and Data Viewer header:** the owner first disliked the centred two-line title, then WITHDREW it. No change.
14. **Meaning Map and Judgment stage (PROPOSED by the Director 2026-10-25 from the owner's questions; owner decides):** (a) a Meaning Map: every word gets a role and a place in a tree. The dictionary already holds is-a trees for nouns and verbs (`public/dictionary/en/rel`), so "emotion, feeling, anger" is a real branch; pointer words (it, that, this, then), time pointers (when, after) and link words are a small CLOSED grammar set (B03B2a and B03B2c) and need no fixed phrases. (b) Emotion and tone reading in B03B3 using those branches. (c) A Judgment stage in the mind loop (7A, after M1): finds the thing that limits the most progress (not always the biggest item), measures pace against a deadline, plans with spare room (aim to finish before the date), and says so in plain words with a short visible list. Not designed yet: needs its own design check.
15. **Knowledge packs and compression:** the owner wants a lot of knowledge inside AXON. Honest answer given 2026-10-25: lossless compression of plain text reaches about 3x to 5x (more with a trained dictionary, rarely 10x); 100 MB to 1 MB is not possible without losing information; it is possible only by choosing what to keep (extraction, summarizing, structured facts). Plan under FL6 when the first pack is chosen.
16. **Drawing:** AXON should be able to draw (lines, dots, from a reference, and by its own method). Not planned; needs a Think-Through and an owner decision about what "draw" means (vector shapes from rules, tracing a reference, or a model).
17. **Not offline-only:** AXON's aim includes the internet and every AI tool, each behind a permission toggle (see roadmap owner rule 7). Network layer and key storage SK0 stay the gate.
18. **System audit (PROPOSED):** one pass by the Director over every built tool with the Think-Through questions (what is wrong, what was not thought of, can it do what is wanted, is it the right and current way, should the brain do it). Candidates: Summarizer, Text Cleaner, Pattern Tester, Device Profile, Image editor, Background Proof. Output: one table, no code changes.
19. **Stray files in the repository top level (cleanup candidates, Z):** `AXON_ROADMAP_V17_8 (1).md`, `AXON_ROADMAP_V16_7.md`, `AXON_ROADMAP_V16_8.md`, `AXON_ROADMAP.md` (stale roadmap copies).

