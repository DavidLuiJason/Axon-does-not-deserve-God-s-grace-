# Things treated as approved because the owner did not answer

Rule (owner, 2026-10-26): when the owner does not answer a proposal, the Director treats it as approved so work can go on, but writes it HERE. The owner can ask "show me what was auto-approved" at any time and reject or change any line. The Director still brings every decision to the owner first and never approves silently.

| Date | What | Where | Status |
|---|---|---|---|
| 2026-10-25 | Teach and correct verb senses (which dictionary senses of "mean" count as a lesson or a correction) | `meaning/teach/teachSenses.ts` header | proposed; not answered yet |
| 2026-10-26 | Tone sense groups: which dictionary senses count as urgent, angry or harsh, and the "a quarter of the senses" rule | `meaning/tone/toneSenses.ts` header | proposed; treated as approved, owner did not answer |
| 2026-10-26 | Sense-by-context settings: window of 6 words, "decided" only with evidence and a clear gap, neighbour glosses at half weight | `meaning/sense/readSenses.ts` | proposed; treated as approved (the owner said to build it now) |
| 2026-10-26 | The rebuilt notes contract was replaced by the real one from the owner's mini-base | `memory/notes/notesTypes.ts` | settled; no owner decision needed |
| 2026-10-26 | Tone test sentences and sense-test sentences are written by the Director, not collected from real users | `tests/toneGlue.test.ts`, `tests/senseContext.test.ts` | owner may replace them with real sentences |

Earlier accounts also listed proposals "for the owner's approval" on the board and in annex A15 (word groups). The next Director should add any that are still unanswered to this table.

2026-11-07 | the owner's yes on adding 'also' as a split word for MR1 was not given; treated as approved because 'also' was already in the closed word set and the change needs no code. Overrule on request.
2026-11-10 | the owner delegated the closed choice words ("decide yourself"): YES to all prepared words except QR single letters l, m, q, h | src/tools/runners/*Words.ts | decided by the Director; overrule on request.
2026-11-13 | the owner said the Director decides the games rules: every tier is always playable; progress only RECOMMENDS a tier (mastered after 3 plays with at least 70% correct; recommended is one above the highest mastered); saved under axon.games.progress.v1 | src/games/progress.ts | decided by DT3; overrule on request.
2026-11-13 | the difficulty order of the curated question banks (which questions count as easy or hard) is DT3's judgement | src/games/rounds/depth.ts RANKS | decided by DT3; overrule on request, and a second reader may check it (docs/GAMES_SECOND_READER_PACK.md).
