# Owner requests and wishes (recorded 2026-10-26, from the owner's dictated message)

Nothing here is built yet unless marked. Order of work stays: one step at a time, brain first. The Director adds new wishes at the bottom and ticks them when built.

## Self-testing code (the Claude-like habit) [wish]
- AXON builds complex code and tests it itself in a sandbox: runs it, attacks it with nasty cases, finds problems, fixes, and RE-RUNS every time. It never gives code it has not run.
- AXON can take code the owner gives it (for example from another AI), find problems, say what each problem was, and either offer the fix or give the fixed code, as the owner asks. It knows how to test and verify.
- Plan: part of AXON Code (AC2 to AC4) and the Mind system loop (M1: plan, act, check; success test written first). The method used by the Director (mutation tests) is the model.

## Frustration (needs the tone glue, built 2026-10-26) [wish]
- When AXON detects frustration it does a full plan and deep check from the foundation: what is failing, why the owner is probably frustrated, what the real fix is. No empty "I know you're frustrated". It may say it understands, say it thought it through, state the problem first, then give a solution, in flexible wording (the personality is not built yet).
- Director note: today a weak tone flag can fire by mistake ("he is sore"), so the deep dive must start only on strong signals or repeated trouble, and its first step is to check AXON's own last answer. Words inside quotes, "you are useless", "fed up", "sick of", "this frustrates me" are not read yet (known limits, to be fixed; the owner suspects more exist).

## Knowing its own limits [wish]
- AXON knows what it can and cannot do (tools, device). For a big job it splits the work into sections.
- It does not guess device limits: it says "I do not know my limits on this device; run tests?" and, if the owner agrees, runs several tests (speed, memory, heavy code), records the result, and either shows it or deletes the test work and keeps the numbers.

## Understanding people [wish]
- Filler words, grammar mistakes, human pauses. A word's type and tone when given a single word. Reverse engineering.

## Video, images, knowledge packs [wish]
- Analyze video frame by frame, extract the audio, compare with built-in compressed knowledge packs (very compressed images, only the needed parts kept).
- Must never lag the phone: packs sit in storage and are loaded only when needed, not kept in RAM. Needs a full plan before any work (size budget, loading, speed).

## Laws [owner rule]
- AXON's laws are the owner's own, not copied from other AI tools. Any law needed goes through the owner, who tests and approves it. The basic laws already in the roadmap stay.

## Thinking tree [wish, at the end]
- A branch-tree view of how AXON thinks and reaches an output, so the owner can see what to work on. Wanted after everything else; related to the "how did you understand" view (R).

## Explainer [done]
- Plain-words file on how AI tools learn: `docs/HOW_AI_LEARNS.md`.

## Process [owner rule]
- Items treated as approved without an answer are listed in `docs/AUTO_APPROVED.md`.

## AXON OFFERS (owner wish, 2026-10-28) [wish W15]
- AXON should make the owner's life easier: it notices what the owner might want and offers it ("say yes and I will start this"), or invites the owner to say what they want. Verdict (rule 12): WORKS ONLY IF it is built on the Judgment stage (7C) and the Router (R1), offers are rare and relevant, nothing runs without the owner's yes, the owner can switch it off, and a refused offer is not repeated. CANNOT JUDGE how often the owner will like it until a small version is tried. Design job OFFER-D (Director), then one builder job.
- CONFIRM, NOT ASK: AXON says what it understood and proceeds; it asks only when it cannot choose or the action has a cost or cannot be undone (OPEN_ITEMS 55).

## MEMORY COMPACTION (owner wish, 2026-10-28)
- AXON's memory nodes must be updated and SUMMARISED so they take little space, without being damaged: the meaning must survive, and AXON must still be able to understand and use them. Nothing in the roadmap plans this yet (only searchable compression of shelves, FL6). Director PROPOSAL for the design job MEM-D: three tiers (working note, summary, archive); the original always stays in the compressed archive (never lost, roadmap 7F rule 4); only the summary is loaded; a summary is accepted only if a fixed list of questions gets the SAME answers from the summary as from the original (a round-trip test), and a failed summary is not used; contradictions and corrections never get summarised away; the owner can open the original. Honest limit: a summary loses detail by definition, so the test is about the questions that matter, not about every word.

## 2026-10-30 (owner, dictated; Director verdicts per roadmap rule 12; PROPOSED, nothing built; each needs a design job and the owner's yes)
**R-U1 UNDERSTANDING REPAIR (the "decoder").** The owner wants AXON to break any incoming message (from the owner or from another AI tool) into a simplified meaning for the brain, notice what does not belong (repeats, restarts, a stray fragment between two parts that join, words it does not know, a message sent twice) and still understand, the way Claude read the owner's foggy dictation (repeated taps in the middle of a text and new recordings). DESIGN (Director): a new stage between 3 ANALYSIS and 4 MEANING; bounded cheap checks in a fixed order; unknown word: nearest dictionary words by spelling distance and by fit with its neighbours (the noisy-channel method of spelling correctors); repeated or restarted span: keep the last complete version; a message that repeats an earlier one is the same request, not a new question; each repair keeps the original, is labelled INFERRED (7F rule 7) and shows in the trace; no phrase lists (FL13). HOW THE BEST SYSTEMS DO IT: large trained models absorb this noise implicitly, which needs chips AXON does not have; smaller dictation systems use explicit steps: disfluency removal (repeats, restarts, fillers), spelling and speech-recognition correction by the noisy-channel method, and a dialogue policy that acts, confirms or asks by the expected cost of being wrong. AXON can copy the explicit steps; it cannot copy the implicit understanding. VERDICT: repeats, restarts, typos and unknown-word repair WORKS (common cases: good chance; on long spoken messages like the owner's: FAIR, because mixed-up order and half sentences are hard); scrambled or twisted wording CANNOT JUDGE; the optional model tier (7.12) is the honest tool for that rest.
**R-U2 ACT-OR-ASK BY COST.** Owner 2026-10-30: asking when unsure is better than guessing and failing, but asking on every simple task is annoying and annoyance grows into dislike; so understand more and ask less. DESIGN: decide by the COST of a wrong action (EFFECTS, UNDO and COST already exist in every schema), not by confidence alone: reversible and cheap: act and say what was understood ("I read this as X; tell me if not"); a close tie or one unknown word: show the best result AND ask "did you mean Y?"; irreversible, costly, sending, deleting or money: ask first and name the readings; never ask what the context already answers; one question at most; remember corrections so the same slip is not asked twice. This refines the 2026-10-28 decision (confirm, do not ask) by adding the cost test; owner to confirm. VERDICT: WORKS (the schema fields exist); the quality of the reading depends on R-U1 and on the concept gaps in the roadmap's GAP LEDGER.
**R-W15 DETECTIVE.** Observation, then ranked possible causes labelled INFERRED, then the cheapest check (example from the owner: a plan that cannot state its own prompt count hides gaps). Lives in Judgment (7C) and the Council GAPS seat. VERDICT: WORKS ONLY IF written as typed evidence rules per domain; open-world detective work CANNOT JUDGE.
**R-W16 EMOTION AND PERSONALITY.** Predict how the owner will feel about a reply (wording, effort asked of them, repeated questions) and learn what an odd word means from how and when the owner uses it. VERDICT: WORKS ONLY IF limited to wording (tone) and patterns the owner consented to keep (style profiles, 7D); hidden feelings cannot be read; one short check, never theatre.
**R-W17 DEVICE MANAGER.** List background apps by recent use and memory and offer to close the unneeded ones for a heavy task, ask before closing, offer to reopen. VERDICT: WORKS DIFFERENTLY (HYPOTHESIS from general Android knowledge, not tested on the Infinix): an app can usually stop only other apps' background processes; real force-stop needs an Accessibility Service driving Settings or system rights; closed apps often restart and cost battery. Needs Usage Access permission; Charter ASK for every close; phone test first.
**R-W18 CIPHER AND CODED WRITING.** Writing that hides meaning with more or fewer words, numbers, symbols or stars. VERDICT: WORKS as exact engines with round-trip tests: standard encryption (AES-GCM through the phone's WebCrypto), classic ciphers, agreed coded writing; never invent new cryptography; no "unbreakable" claim; the owner's own text only.
**R-W19 SPEED.** Measure first on the owner's phone (job BM1, not done); then lazy loading, per-message cache, Web Worker, exact engines, spill to storage; the weakest phone tier decides.
**R-P PROCESS (owner 2026-10-30).** (1) Finish the open job before starting another; the Director advises and reminds. (2) Every roadmap item says how it is built or is listed as UNPLANNED. (3) Rules are being skipped by accounts, so the roadmap now opens with a short FIRST SCREEN. (4) The owner's measure: roadmap completeness about 60 percent, about 85 to 90 percent success per prompt; 202 roadmap versions and 300 repositories so far (OWNER-REPORTED).
